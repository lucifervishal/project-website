-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2022 at 10:19 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `categories` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `categories`, `status`) VALUES
(6, 'Shop', 1),
(7, 'Rent', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(75) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `comment` text NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `mobile`, `comment`, `added_on`) VALUES
(5, 'Vishal Parmar', 'dev77501@gmail.com', '8974561547', 'Test query', '2022-10-02 05:14:29');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address` varchar(250) NOT NULL,
  `city` varchar(50) NOT NULL,
  `pincode` int(11) NOT NULL,
  `payment_type` varchar(20) NOT NULL,
  `total_price` float NOT NULL,
  `payment_status` varchar(20) NOT NULL,
  `order_status` int(11) NOT NULL,
  `txnid` varchar(20) NOT NULL,
  `mihpayid` varchar(20) NOT NULL,
  `payu_status` varchar(10) NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `user_id`, `address`, `city`, `pincode`, `payment_type`, `total_price`, `payment_status`, `order_status`, `txnid`, `mihpayid`, `payu_status`, `added_on`) VALUES
(1, 1, 'test', 'test', 110076, 'COD', 164299, 'Success', 4, 'eaad21770607ee0b25ba', '', '', '2020-05-15 10:29:38'),
(2, 5, 'Ghatkopar', 'Mumabi', 400087, 'payu', 7849, 'pending', 1, 'd227ea9c3c94996afb76', '', '', '2022-10-02 09:09:47'),
(3, 5, 'R.no-11, Netaji Subhash Nagar Ramjas Nirankari Sadan,Khairani Road,ASALFA', 'Mumbai', 400084, 'payu', 3499, 'pending', 1, '5ccd78dff7f57b7bb7d7', '', '', '2022-10-02 09:25:23'),
(4, 5, '24 Market, Tanti  Road ,Flat no:02', 'Mumbai', 400022, 'COD', 3499, 'pending', 1, 'd011e96057a2c9c25a10', '', '', '2022-10-02 09:46:41'),
(5, 6, '24 Market, Tanti  Road ,Flat no:02', 'Mumbai', 400022, 'COD', 8499, 'pending', 1, '5b9b7bf4ddc13687a243', '', '', '2022-10-02 03:39:14'),
(6, 7, 'road mp', 'mumbai', 400045, 'COD', 19157, 'pending', 1, '861e47f08669a1e3be59', '', '', '2022-10-07 10:09:11');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `order_id`, `product_id`, `qty`, `price`) VALUES
(1, 1, 2, 1, 155800),
(2, 1, 1, 1, 8499),
(3, 2, 12, 1, 7849),
(4, 3, 13, 1, 3499),
(5, 4, 13, 1, 3499),
(6, 5, 16, 1, 8499),
(7, 6, 26, 1, 659),
(8, 6, 24, 1, 14999),
(9, 6, 13, 1, 3499);

-- --------------------------------------------------------

--
-- Table structure for table `order_status`
--

CREATE TABLE `order_status` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_status`
--

INSERT INTO `order_status` (`id`, `name`) VALUES
(1, 'Pending'),
(2, 'Processing'),
(3, 'Shipped'),
(4, 'Canceled'),
(5, 'Complete');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `sub_categories_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mrp` float NOT NULL,
  `price` float NOT NULL,
  `qty` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `short_desc` varchar(2000) NOT NULL,
  `description` text NOT NULL,
  `best_seller` int(11) NOT NULL,
  `meta_title` varchar(2000) NOT NULL,
  `meta_desc` varchar(2000) NOT NULL,
  `meta_keyword` varchar(2000) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `categories_id`, `sub_categories_id`, `name`, `mrp`, `price`, `qty`, `image`, `short_desc`, `description`, `best_seller`, `meta_title`, `meta_desc`, `meta_keyword`, `status`) VALUES
(1, 1, 0, 'Realme C3 (Frozen Blue, 64 GB) (4 GB RAM)', 9999, 8499, 10, '799153645_303b4a46-a701-4b43-b9c1-d98a2b53422f.jpg', 'Mauris dapibus tellus quis risus maximus molestie. Curabitur eget tortor tellus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus scelerisque quis nisi porta congue. Aenean sed maximus ligula. Vestibulum quis eros id ex condimentum lacinia. Nam interdum finibus odio, sit amet commodo erat varius sed. In at velit velit. Nullam vitae gravida mi. Donec aliquet nunc non ipsum bibendum, et elementum nibh lobortis. Fusce tempor elit at mauris luctus euismod. Donec eu massa eros. Aenean maximus vitae nisl ut sollicitudin. Aenean urna arcu, laoreet at ante eget, maximus mattis lacus. Mauris dapibus tellus quis risus maximus molestie. Curabitur eget tortor tellus.', 1, 'Realme C3 (Frozen Blue, 64 GB) (4 GB RAM)', '', 'Realme C3 (Frozen Blue, 64 GB) (4 GB RAM)', 1),
(2, 1, 0, 'APPLE IPHONE 11 PRO MAX (512GB) - MIDNIGHT GREEN', 165800, 155800, 4, '942626953_iphone.jpg', 'Aenean tempus ut leo nec laoreet. Vestibulum ut est neque.', 'Curabitur eget augue dolor. Curabitur id dapibus massa. Vestibulum at enim quis metus ultrices posuere vitae sit amet eros. Morbi et libero pellentesque, efficitur odio nec, congue lorem. Vestibulum faucibus, risus eget pretium efficitur, neque nulla eleifend purus, non venenatis lorem ligula vel nulla. Fusce finibus efficitur sapien vitae laoreet. Integer imperdiet justo sed tellus dictum, at egestas arcu finibus. Fusce et augue elit. Praesent tincidunt purus in purus dictum volutpat. Aenean tempus ut leo nec laoreet. Vestibulum ut est neque.', 0, 'APPLE IPHONE 11 PRO MAX (512GB) - MIDNIGHT GREEN', '', 'APPLE IPHONE 11 PRO MAX (512GB) - MIDNIGHT GREEN', 1),
(3, 1, 0, 'Samsung Galaxy S10 Plus 1TB (Ceramic White, 12GB RAM)', 115900, 115900, 5, '567328558_samsung-galaxy-s10-plus-1tb-ceramic-white-12gb-ram-.jpg', 'Nullam purus lorem, tincidunt vitae tristique non, imperdiet ut urna.', 'Nullam a nunc et lorem ornare faucibus. Etiam tortor lacus, auctor eget enim at, tincidunt dignissim magna. Interdum et malesuada fames ac ante ipsum primis in faucibus. Proin tincidunt eros eget felis tempor, id volutpat ipsum lacinia. Donec scelerisque risus non purus scelerisque tristique. Mauris enim ligula, condimentum sed iaculis nec, porttitor eu nunc. Sed hendrerit vel arcu vitae iaculis. Phasellus vehicula molestie leo. Nullam purus lorem, tincidunt vitae tristique non, imperdiet ut urna.', 0, 'Samsung Galaxy S10 Plus 1TB (Ceramic White, 12GB RAM)', 'Samsung Galaxy S10 Plus 1TB (Ceramic White, 12GB RAM)', 'Samsung Galaxy S10 Plus 1TB (Ceramic White, 12GB RAM)', 1),
(4, 2, 2, 'SHEEN-SOLID TROUSER-OLIVE', 1999, 1200, 3, '697347005_2__1538219531_49.204.69.38_600x.jpg', 'per inceptos himenaeos. Ut commodo ullamcorper quam non pulvinar.', 'Duis a felis congue, feugiat est non, suscipit quam. In elit lacus, auctor sed lacus eget, egestas consectetur leo. Duis pellentesque pharetra ante, ac ornare nibh faucibus id. Integer pulvinar malesuada nisl. Nulla vel orci nunc. Nullam a tellus eu ex ullamcorper mollis. Donec commodo ligula a accumsan fermentum. Mauris sed orci lacinia, posuere leo molestie, pretium mi. Cras sodales, neque id cursus fermentum, mi purus vehicula sem, vel laoreet lorem justo id tortor. Sed ut urna ut ipsum vestibulum commodo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut commodo ullamcorper quam non pulvinar.', 0, 'SHEEN-SOLID TROUSER-OLIVE', 'SHEEN-SOLID TROUSER-OLIVE', 'SHEEN-SOLID TROUSER-OLIVE', 1),
(5, 2, 0, 'NATURE-LINEN SHIRT-GREEN', 2799, 2399, 8, '812581380_nature_green-0224_600x.jpg', 'a nisl pharetra orci, at condimentum nisl lorem elementum ipsum.', 'Nunc auctor turpis ante, eget bibendum mi mollis in. Aliquam quis neque ut libero malesuada auctor. Aliquam interdum enim at commodo gravida. Donec nisl sem, molestie ut quam quis, vulputate venenatis ipsum. Aenean quis ex ut magna accumsan fringilla. Quisque id ex massa. Sed libero ante, fringilla ac condimentum in, porttitor ac risus. Integer mattis odio nec nunc semper imperdiet. In porttitor tellus eget sapien vulputate, eu euismod lacus aliquet. Maecenas molestie elit augue, sit amet fringilla dolor congue et. Nunc eu libero auctor, sollicitudin lectus quis, porta ligula. In vel ullamcorper risus. Nullam viverra, mi sit amet laoreet luctus, urna nisl pharetra orci, at condimentum nisl lorem elementum ipsum.', 0, 'NATURE-LINEN SHIRT-GREEN', 'NATURE-LINEN SHIRT-GREEN', 'T-Shirt, NATURE-LINEN SHIRT-GREEN', 1),
(6, 2, 1, 'Monte Carlo Turquoise Blue Solid Collar T Shirt', 1999, 1500, 8, '931830512__8-(1)-E5x-104831-NJD.jpg', 'lacus quis urna tristique suscipit. Praesent vitae mi mollis dui facilisis convallis eu faucibus augue.', 'Duis in risus quis lectus dictum fringilla. Aenean tempor pellentesque velit id ullamcorper. Ut id aliquam odio. Morbi id pharetra libero, ut tempor nisi. Maecenas a lectus nec risus maximus rutrum. Mauris vel elit ut magna semper laoreet nec sed magna. Quisque eleifend vel sem non malesuada. Interdum et malesuada fames ac ante ipsum primis in faucibus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vestibulum eget posuere orci, eu ultrices sapien. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam sit amet ex dictum nisl bibendum elementum non in turpis. In bibendum ipsum nunc, bibendum lacinia lacus maximus eu. Interdum et malesuada fames ac ante ipsum primis in faucibus. Vivamus aliquam lacus quis urna tristique suscipit. Praesent vitae mi mollis dui facilisis convallis eu faucibus augue.', 0, 'Monte Carlo Turquoise Blue Solid Collar T Shirt', 'Monte Carlo Turquoise Blue Solid Collar T Shirt', 'Monte Carlo Turquoise Blue Solid Collar T Shirt', 1),
(7, 4, 0, 'Floral Print Polo T-shirt', 1900, 1350, 7, '309027777_Floral-Print-Polo-T-shirt.jpg', 'isl pharetra orci, at condimentum nisl lorem elementum ipsum.', 'Nunc auctor turpis ante, eget bibendum mi mollis in. Aliquam quis neque ut libero malesuada auctor. Aliquam interdum enim at commodo gravida. Donec nisl sem, molestie ut quam quis, vulputate venenatis ipsum. Aenean quis ex ut magna accumsan fringilla. Quisque id ex massa. Sed libero ante, fringilla ac condimentum in, porttitor ac risus. Integer mattis odio nec nunc semper imperdiet. In porttitor tellus eget sapien vulputate, eu euismod lacus aliquet. Maecenas molestie elit augue, sit amet fringilla dolor congue et. Nunc eu libero auctor, sollicitudin lectus quis, porta ligula. In vel ullamcorper risus. Nullam viverra, mi sit amet laoreet luctus, urna nisl pharetra orci, at condimentum nisl lorem elementum ipsum.', 0, 'Floral Print Polo T-shirt', 'Floral Print Polo T-shirt', 'Floral Print Polo T-shirt', 1),
(8, 4, 0, 'Floral Embroidered Polo T-shirt', 1120, 1900, 10, '651584201_Floral-Embroidered-Polo-T-shirt.jpg', 'rius, lacus velit aliquam ex, in dignissim sem eros ac erat. Vestibulum ac arcu tortor.', 'Vestibulum in auctor turpis. Quisque hendrerit eget turpis et molestie. Phasellus nec nibh a lacus rhoncus eleifend. Donec suscipit id diam non mattis. Fusce eu luctus leo. Etiam eget dui libero. Etiam eros lorem, rhoncus et convallis eget, tempus vel tellus. Nam at diam quis nisl tincidunt aliquam. Quisque placerat magna non libero interdum varius vel id risus. Vivamus mollis maximus fermentum. Donec eget nulla dui. Sed ultricies malesuada metus, non feugiat purus fringilla ac. Interdum et malesuada fames ac ante ipsum primis in faucibus. Integer accumsan, tortor id eleifend varius, lacus velit aliquam ex, in dignissim sem eros ac erat. Vestibulum ac arcu tortor.', 1, 'Floral Embroidered Polo T-shirt', '', 'Floral Embroidered Polo T-shirt', 1),
(9, 4, 0, 'Floral Print Polo T-shirt Latest', 650, 1560, 10, '526258680_Floral-Print-Polo-T-shirt1.jpg', 's mus. Vestibulum eget posuere orci, eu ultrices sapien. Orc', 'aximus rutrum. Mauris vel elit ut magna semper laoreet nec sed magna. Quisque eleifend vel sem non malesuada. Interdum et malesuada fames ac ante ipsum primis in faucibus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vestibulum eget posuere orci, eu ultrices sapien. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam sit amet ex d', 1, 'Floral Print Polo T-shirt Latest', '', 'Floral Print Polo T-shirt Latest', 1),
(10, 4, 3, 'test', 100, 10, 1, '977077907_651584201_Floral-Embroidered-Polo-T-shirt.jpg', 'test', 'test', 0, '', '', '', 1),
(11, 2, 0, 'Test1', 100, 50, 10, '457926432_697347005_2__1538219531_49.204.69.38_600x.jpg', 'Test', 'test', 0, '', '', '', 1),
(12, 7, 6, 'Canon E4570', 9625, 7849, 10, '351416730_Canon E4570.jpg', 'Cost efficient compact wireless all in one printer with fax and auto duplex printing. Print, Scan, Copy, Fax. ISO standard print speed (A4): 8.8ipm black / 4.4ipm colour. Hi-speed USB 2.0, WiFi, Mopria, AirPrint, direct connection (Wireless LAN)Recommended print volume: 200-500 pages.', '-For installation support or product queries, kindly contact Canon- Timings: 9:30am-5:30pm (Mon to Fri) (24X7 support)\r\n-Connectivity - Wi-Fi, Wi-fi Direct, USB, Canon Selphy App, Apple Airprint ; Smart Speaker compatible\r\n-Ideal usage - Home and Small Office, Regular usage (200 prints per month)\r\n-Printer Type- Ink Efficient; Functionality - All-in-One (Print, Scan, Copy, Fax), Duplex Printing , ADF ; Printer Output - Color\r\n-Print yield is based on the consumption data from the succeeding ink cartridge and not the first ink cartridge. \r\n-Yield will be low if printing photos. \r\n-Compatible Ink Cartridge - PG-47 (Black), CL-57s (Color) --Print Yield - 400 prints (Black and White), 180 prints (Color) As per ISO/IEC 19752, ISO/IEC 19798\r\n-Use only original Canon Ink Cartridge. Using counterfeit ink will harm your printer and render the warranty void', 1, 'Canon E4570', 'All-in-One Wi-Fi Ink Efficient Colour Printer with FAX/ADF/Duplex Printing (Black)- Smart Speaker Compatible, Standard', 'Printers', 1),
(13, 7, 6, 'HP Deskjet 2331', 4332, 3499, 5, '470958751_HP Deskjet 2331.jpg', 'For Home/Small Office, Compact Size, Reliable, Easy Set-Up Through HP Smart App On Your Pc Connected Through USB, Ideal for Home.', 'SIMPLE SET UP FROM YOUR PC: Use the HP Smart app to set up with USB in few easy steps. Automatic paper sensor : No\r\nRELIABLE CONNECTIVITY : High-speed USB 2.0 Connectivity\r\nHighly printer for your print, scan and copy needs\r\nSAVE YOUR PRODUCTIVE TIME: High speed printing for Home needs; Black: Up to 7.5 ppm (ISO) ;Color: Up to 5.5 ppm (ISO)\r\nPEACE OF MIND SERVICE SUPPORT: HP ON-SITE 1-YEAR WARRANTY (Use genuine HP 805 Black Original Ink Cartridge,HP 805 Tri-Colour Original Ink Cartridge)\r\nVERSATILE PRINT/MEDIA OPTIONS: Supports A4; B5; A6; DL envelope', 0, 'HP Deskjet 2331', 'rent', 'printers', 1),
(14, 7, 6, 'HP Ink Tank 415', 16280, 12999, 15, '486403913_51zUFJsiNHL._SL1500_.jpg', 'Inkjet Printer 1N, (Black Ink Cartridge 1N,Color Ink Cartridge 1N,Power Cord 1N, USB Cable 1N,User Manual 5N)', 'Reliable connectivity: High-speed USB 2.0, Wi-Fi, Bluetooth LE\r\nConvenient printing: Get up to 8,000 color prints at just 20 paise/page, 6,000 prints at10 paise/page\r\nMess-free, simple ink management: Transparent ink tanks to let you see how much ink you have left. Get convenient, spill-free refill, with resealable bottles HP\'s unique ink tank system\r\nPrint from your smart phone: Print, scan, copy from anywhere using the HP Smart app\r\nPrinter type: All-in-one print, copy, scan; compact, wireless, color printer for home', 1, 'HP Ink Tank 415', 'inkjet printers', 'printers', 1),
(15, 6, 5, 'Canon PIXMA MG2577s', 3825, 3199, 5, '303478084_71imdJGiCHL._SL1500_.jpg', '1 Printer, 1 Power cord, 2 cartridges, 1 Installation CD, 1 User manual, 1 USB Cable', 'Printer Type - Inkjet; Functionality - All-in-One (Print, Scan, Copy); Printer Output - Color. Selectable Resolution : 25 - 19200dpi\r\nConnectivity-USB; Compatibility: Windows 8 / Windows 7 / Window Vista / Windows XP, Mac OS X v10.6.8. Auto Power On\r\nNo LCD display on printer; Ideal usage - Occasional Home Printing (less than 50 pages per month)\r\nPages per minute - 8.0 ipm (Black), 4.0 ipm (Colour); Cost per page - Rs.7 (Black), Rs.9 (Color) - As per ISO standards (Cost per page will be higher for printing photos)\r\nCompatible Ink: Black-PG745s,PG745,PG745XL, Color-CL746s,CL746,CL746XL;1 set of PG745s & CL746s ink cartridges, inside the box\r\nPage Yield: PG745s-100pgs, CL746s-100pgs- As per ISO standards. (Page yield is based on the consumption data from the succeeding ink cartridge but not the first ink cartridge. Yield will be lesser while printing photos)\r\nPage size supported- A4, A5, B5, LTR, LGL, 4 x 6\", 5 x 7\", Envelopes (DL, COM10), Custom size (width 101.6 - 215.9mm, length 152.4 - 676mm). Duplex Print - No, Print resolution - 4800 x 600 dpi\r\nWarranty - 1 year carry-in warranty from the date of purchase. Use only original Canon ink. Using counterfeit ink will harm your printer as well as render your warranty void', 0, 'Canon PIXMA MG2577s', 'canon printers', 'printers', 1),
(16, 7, 6, 'HP 115', 9944, 8499, 10, '453806761_51U6520TWgL._SL1500_.jpg', 'Inkjet Printer 1N, (Black Ink Cartridge 1N,Color Ink Cartridge 1N,Power Cord 1N, USB Cable 1N,User Manual 5N)', 'PRINTER FOR YOUR PRINT NEEDS : Up to 8,000 colour or 6,000 black pages are included\r\nHIGH VOLUME, PRINTING: Print worry-free at 10p for Black and 20p for Colour\r\nRELIABLE CONNECTIVITY : High-speed USB 2.0 Connectivity, Vertical alignment accuracy +/- 0.042 mm\r\nCONVENIENT INK MANAGEMENT: Easy to fill ink tanks lets you see how much ink you have left. With newly designed ink bottles specific for each colour itâ€s easier than ever to fill and refill.\r\nSAVE YOUR PRODUCTIVE TIME: Enjoy plain paper printing speeds of 19 Draft (Black) / 15 Draft (Colour), Help save time with customizable shortcuts, using Smart Tasks. Print your business documents quickly with fast print speeds.\r\nOS Compatibilty: Microsoft Windows 10, 8.1, 8, Windows Vista, Windows XP SP3 or higher (32-bit only): Windows Server 2008 32-bit (SP1 or greater), Windows Server 2008 64-bit (SP1 or greater), Windows Server 2008 R2 64-bit, Windows Server 2008 R2 64-bit (SP1), Windows Server 2012 64-bit, Windows Server 2012 R2 64-bit, Windows Server 2016, OS X v10.10 Yosemite, OS X v10.11 El Capitan, macOS Sierra v10.12 (previously OS X), Linux OS', 0, 'HP 115 Color Single Function Ink Tank Printer', 'inkjet printer', 'printers', 1),
(17, 6, 4, 'HP M0H50A', 1095, 1095, 40, '762233063_OFF.INK.86426665_1656593408472.jpg', 'Cartridge Colors: Tri-color\r\nPrint Technology: HP Thermal Inkjet\r\nProduct type: Printheads', 'Print high-quality text, graphics, and photos for your office with simple to replace printheads. It\'s easy with the high-capacity HP ink tank system, Original HP ink, and Original HP printheads.\r\nExtend the life of your printer with replaceable printheads. Just replace and resume printing.\r\n\r\nWork with less interruption—print page after page without having to worry about printheads or ink.[1]\r\n\r\nOutstanding quality and durability from HP\r\n\r\nImpress with outstanding HP quality. Print crisp documents with sharp lines, graphics, and text with Original HP inks and printheads.\r\nCount on vibrant graphics and eye-popping photos for your home and small business documents, time after time.\r\n\r\nCount on reliable performance—Original HP inks and printheads are designed to deliver exceptional prints.', 1, 'HP M0H50A Tri-color Replacement GT Printhead', 'Printhead', 'inks', 1),
(18, 7, 6, 'HP Smart Tank 670', 13999, 12899, 15, '481124883_71iTKGrwrFL._SL1500_.jpg', 'Brand	HP\r\nConnector Type	Bluetooth, Wi-Fi, USB, Ethernet\r\nPrinting Technology	Inkjet\r\nSpecial Feature	Auto-Duplex\r\nColour	Gray\r\nModel Name	HP Smart Tank 670\r\nPrinter Output	Colour\r\nMaximum Print Speed (Colour)	7 ppm\r\nMax Print speed Monochrome	12 ppm\r\nItem Weight	7000 Grams', 'ENVIRONMENTAL CONSCIOUS PRINTING : This printer is made from recycled printers and other electronics more than 25% by weight of plastic; EPEAT Silver certified;QUICK MOBILE SETUP with HP SMART APP: The guided, step-by-step set up via HP Smart app; Use a smartphone or tablet to set up your printer and connect to your local wireless network\r\nHIGH VOLUME PRINTING: Print worry-free at10 paise for Black and 20 paise for Colour;HIGHLY DUPLEX WIFI PRINTER FOR YOUR PRINT, SCAN and COPY NEED : with integrated ink tanks and an automatic ink and paper sensor with Smart guided buttons. Up to 8,000 colour or 6,000 black pages are included', 0, 'HP Smart Tank 670', 'all in one', 'printers', 1),
(19, 6, 5, 'Canon Pixma G3000', 177195, 14999, 5, '924749003_61tk3NENc7L._SL1500_.jpg', 'Brand	Canon\r\nConnector Type	Wi-Fi, USB\r\nPrinting Technology	Ink Tank\r\nSpecial Feature	**Cost per print - 9 paise (Black & White), 33 paise (Colour) - As per ISO standards. **Printing cost and the print yield for A4 paper (21.0x29.7 cm) of G series, please visit Canon India website for more details, 2 Additional Black ink bottles inside the box, along with 1 set of Cyan, Magenta, Yellow and Black Ink bottle (Total 6 ink bottles), Wi-Fi, Wi-Fi Direct, PIXMA Cloud Link, Canon PRINT Inkjet/SELPHY App, All in One Wireless Printer- Print, Copy, Scan (Colored), *Warranty – One Year onsite or 15000 Prints whichever is earlier. *Warranty is subject to Terms & Conditions. For details, please visit Canon India website, User Replaceable Print Heads**Cost per print - 9 paise (Black & White), 33 paise (Colour) - As per ISO standards. **Printing cost an… See more\r\nColour	Black\r\nRecommended Uses For Product	Home\r\nModel Name	G3000\r\nPrinter Output	Colour\r\nMaximum Print Speed (Colour)	5 ppm\r\nMax Print speed Monochrome	8.8 ppm', 'Print, Scan, Copy;2 Additional Black ink bottles inside the box, along with 1 set of Cyan, Magenta, Yellow and Black Ink bottle (Total 6 ink bottles)\r\nPrint Speed (A4): 8.8/5.0 (Mono/Colour) images per minute; Prints a 10.16 x 15.24cm borderless photo in 60s;4800x1200 dpi, Borderless Printing. CIS Flatbed Scanner, up to 600x1200 dpi, up to 21 copies\r\n100 sheets Paper Input, 50 sheets Paper Output;100 sheets Paper Input, 50 sheets Paper Output\r\nInk Bottle GI-790.C,M,Y,K: Standard Yield Mono 6000 prints#. Composite Colour 7000 prints#. Inbox Mono 18000 prints#;**Cost per print - 9 paise (Black & White), 33 paise (Colour) - As per ISO standards; Warranty – One Year onsite or 15000 Prints whichever is earlier*\r\nControl Method: Application', 0, 'Canon Pixma G3000', 'Canon printers', 'printers', 1),
(20, 6, 5, 'Epson EcoTank L3211', 14999, 13199, 8, '694682244_514Z574sBBL._SL1200_.jpg', 'Brand	Epson\r\nConnector Type	USB\r\nPrinting Technology	Inkjet\r\nSpecial Feature	network ready\r\nColour	Black\r\nRecommended Uses For Product	Office, Home\r\nModel Name	L3211\r\nPrinter Output	Colour\r\nMaximum Print Speed (Colour)	15 ppm\r\nMax Print speed Monochrome', 'Printer Type - Ink Tank; Functionality - All-in-One (Print, Scan, Copy) , Scanner type - Flatbed; Printer Output - Colour; Connectivity -USB, App\r\nPages per minute - 33 pages (Black & White), 15 pages (Colour) ; Cost per page - 7 paise (Black & White), 18 paise (Colour) - As per ISO standards\r\nIdeal usage - Home and Small office, Regular / Heavy usage (more than 300 pages per month)\r\nPage size supported - A4, A5, A6, B5, C6, DL ; Duplex Print - Manual ; Print resolution - 5760 x 1440\r\nControl Method: Application', 1, 'Epson EcoTank L3211', 'Epson printers', 'printers', 1),
(21, 6, 5, 'Brother DCP-T226', 13999, 10999, 6, '329067762_61mF58kHWAL._SL1500_.jpg', 'Brand	Brother\r\nConnectivity Technology	USB\r\nPrinting Technology	Inkjet\r\nColour	White\r\nRecommended Uses For Product	Home\r\nSeries	DCP-T226\r\nPrinter Output	Colour\r\nMaximum Print Speed (Colour)	11 ppm\r\nMax Print speed Monochrome	28\r\nOperating System	Linux, Mac, Windows', 'Printer Type - Ink Tank ; Functionality - All In One (Print, Scan, Copy) ; Printer Output - Color\r\nConnectivity - USB, POWER SOURCE: 220 - 240 V AC 50/60 Hz\r\nGenuine Ink Bottles - BTD60BK, BT5000 C, M, Y; Page Yield - 7500 pages (Black), C, M, Y - 5000 pages each (Colour)\r\nInk Color : Black, Cyan, Magenta and Yellow\r\nA4, Letter, Legal, Mexico Legal, India Legal, Folio, Executive, A6, Envelopes, Photo (4\" x 6\")/(10 x 15 cm), Photo 2L (5\" x 7\")/(13 x 18 cm)', 0, 'Brother DCP-T226', 'Brother printers', 'printer', 1),
(22, 6, 5, 'Brother DCP-T426W', 15590, 13999, 10, '240229083_71UEoZnyp1L._SL1500_.jpg', 'Brand	Brother\r\nConnectivity Technology	Wi-Fi, USB\r\nPrinting Technology	Inkjet\r\nSpecial Feature	network ready\r\nColour	White\r\nRecommended Uses For Product	Office, Home\r\nSeries	DCP-T426W\r\nPrinter Output	Colour\r\nMaximum Print Speed (Colour)	11 ppm\r\nMax Print speed Monochrome	28', 'Printer Type - Ink Tank ; Functionality - All In One (Print, Scan, Copy) ; Printer Output - Color\r\nConnectivity - USB, Wi-Fi, Wi-Fi Direct, POWER SOURCE: 220 - 240 V AC 50/60 Hz\r\nGenuine Ink Bottles - BTD60BK, BT5000 C, M, Y; Page Yield - 7500 pages (Black), C, M, Y - 5000 pages each (Colour)\r\nInk Color : Black, Cyan, Magenta and Yellow\r\nA4, Letter, Legal, Mexico Legal, India Legal, Folio, Executive, A6, Envelopes, Photo (4\" x 6\")/(10 x 15 cm), Photo 2L (5\" x 7\")/(13 x 18 cm)', 0, 'Brother DCP-T426W', 'Brothers printers', 'printers', 1),
(23, 6, 5, 'HP Ink Tank 530', 21516, 19599, 20, '874020745_51vVkSBDfGL._SL1500_.jpg', 'Brand	HP\r\nConnectivity Technology	Wi-Fi\r\nPrinting Technology	Ink Tank\r\nSpecial Feature	Wireless,Compact\r\nColour	INVALID DATA\r\nRecommended Uses For Product	Office\r\nSeries	HP Smart Tank 530 AiO Printer\r\nPrinter Output	Colour\r\nMaximum Print Speed (Colour)	16 ppm\r\nMax Print speed Monochrome	22 ppm', 'HIGH VOLUME PRINTING: Print worry-free at 10p for Black and 20p for Colour;INCREASE PRODUCTIVITY WITH AUTOMATIC DOCUMENT FEEDER: This all-in-1 printer\'s 35-page automatic document feeder helps you breeze through scan and copy jobs quickly\r\nRELIABLE CONNECTIVITY : High-speed USB 2.0 Connectivity, Wi-Fi , Bluetooth LE;PEACE OF MIND SERVICE SUPPORT: On-site 6Hrs Call to Resolution (Installation and Break-fix) covering 400 cites with 444 locations (Use genuine HP GT53XL 135-ml Black Original Ink Bottle; HP GT52 70-ml Cyan Original Ink Bottle; HP GT52 70-ml Magenta Original Ink Bottle; HP GT52 70-ml Yellow Original Ink Bottle)', 0, 'HP Ink Tank 530', 'hp printers', 'printers', 1),
(24, 6, 5, 'Epson PictureMate PM-520 Photo Printer', 177999, 14999, 10, '561579178_71t+xXItkmL._SL1380_.jpg', 'Brand	Epson\r\nConnector Type	USB\r\nPrinting Technology	Photo Printer\r\nSpecial Feature	Rechargeable,Portable\r\nColour	black\r\nRecommended Uses For Product	Office, Home\r\nModel Name	PictureMate\r\nPrinter Output	Colour\r\nMax Print speed Monochrome	1.8 Images per Minute\r\nItem Weight	3820 Grams', 'Print speed up to 36 secs\r\nRechargeable battery option\r\nPrint resolution up to 5760dpi\r\nWi-Fi, Wi-Fi Direct, Epson Connect\r\nLightweight and portable\r\nCountry of Origin: Philippines', 0, 'Epson PictureMate PM-520', 'Epson printers', 'printers', 1),
(25, 6, 5, 'HP 720 WiFi Duplex Printer', 23598, 20349, 10, '607965672_61yBXJsxe9L._SL1500_.jpg', 'Brand	HP\r\nConnector Type	Bluetooth, Wi-Fi, USB\r\nPrinting Technology	Ink Tank\r\nSpecial Feature	Smart guided buttons\r\nColour	Grey White\r\nRecommended Uses For Product	Home and Small office, Regular / Heavy usage (more than 400 pages per month)\r\nModel Name	HP Smart Tank 720 All-in-One Printer\r\nPrinter Output	Colour\r\nMaximum Print Speed (Colour)	9 ppm\r\nMax Print speed Monochrome	15 ppm', 'ENVIRONMENTAL CONSCIOUS PRINTING : This printer is made from recycled printers and other electronics more than 25% by weight of plastic; EPEAT Silver certified;WORRY FREE DUAL BAND WIRELESS WITH SELF HEALING: Get better range, faster and more reliable connections using dual band Wi-Fi.Print, scan, and copy from anywhere with the best-in-class mobile print app: HP Smart\r\nQUICK MOBILE SETUP WITH HP SMART APP: The guided, step-by-step set up via HP Smart app; Use a smartphone or tablet to set up your printer and connect to your local wireless network;HIGH VOLUME PRINTING: Print worry-free at10 paise for Black and 20 paise for Colour', 0, 'HP 720 WiFi Duplex Printer', 'hp printers', 'printers', 1),
(26, 6, 4, 'HP 680 Black Ink Cartridge', 952, 659, 50, '806616871_Screenshot 2022-10-07 210037.png', 'Cartridge Type: Ink Cartridge\r\nColor: Black\r\nPage Yield: 480 Pages\r\nPigment Based Ink', 'You can get clear-quality and sharp prints by using this ink cartridge from HP. The ink is durable and reliable, so you can use it to get long-lasting print-outs. What\'s more, the cartridge body is also made by using recycled contents.\r\n\r\nDurable Prints\r\n\r\nIt offers high-quality prints that can resist water droplets and fading caused due to light exposure.\r\n\r\nReliability\r\n\r\nOriginal ink cartridges from HP are also highly reliable, so you can be assured that they will deliver good-quality performance every time.\r\n\r\nPermanence\r\n\r\nIf you do not want the prints in your print-outs to fade away then you can trust this ink, as it is long-lasting.\r\n\r\nEco-Friendly\r\n\r\nThe new ink cartridge bodies are made of recycled content which makes it eco-friendly.\r\n\r\nQuality\r\n\r\nIt offers premium print quality, so you can read your documents without putting any effort into your eyes.', 0, 'HP 680 Black Ink', 'hp ink', 'inks', 1),
(27, 6, 4, 'R C Print Canon G Series', 1999, 599, 50, '113809125_Screenshot 2022-10-07 210440.png', 'Cartridge Type: Ink Bottle\r\nColor: Magenta, Cyan, Black, Yellow\r\nPage Yield: 6000 Pages/Black & 7000 Pages/Colors Pages\r\nDye Based Ink', 'Compatible With\r\nCanon GI 790 G1000 , G1010 , G1100 , G2000 , G2002 , G2010 , G2012 , G2100 , G3000 , G3010 , G3012 , G3100 , G4000 , G4010 , G1900 , G2900 , G3900 , G1800 , G2800 , G3800\r\nSales Package\r\n4 Ink Bottle-70 ml Each (Cyan,Yellow,Magenta), 135 ml Black color\r\nModel Name\r\nG1000, G2000, G2002, G3000, G4000', 0, 'R C Print Canon', 'G series', 'inks', 1),
(28, 6, 4, 'Canon CL 746 S Multicolor Ink', 1007, 799, 25, '725378562_Screenshot 2022-10-07 210541.png', 'Cartridge Type: Ink Cartridge\r\nColor: Tri Color\r\nPage Yield: 100 Pages\r\nPigment Based Ink', 'Ink Color- Tri Color; Ink Type-Dye||Yield- 100 pages. As per- ISO standards for A4 size||Compatible Printers- MG2570S / MG2570 MG3070S / MG2970 / MG3077S / MG2577S / MG2470 / iP2870S/TS207/ TS307 / TS3170 / TS3370||Use only original Canon Ink Cartridge. Using counterfeit ink will harm your printer as well as render the warranty void', 0, 'Canon CL 746 S', 'canon inks', 'inks', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `sub_categories` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `categories_id`, `sub_categories`, `status`) VALUES
(1, 2, 'T-Shirt', 1),
(2, 2, 'Trouser', 1),
(3, 4, 'Shirt', 1),
(4, 6, 'Inks', 1),
(5, 6, 'Printers', 1),
(6, 7, 'Printers', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `email`, `mobile`, `added_on`) VALUES
(5, 'vishal', 'vishal123', 'dev77501@gmail.com', '8974561784', '2022-10-02 09:05:54'),
(6, 'VISHAL PARMAR', '123456', 'TASHU21@gmail.com', '2568945689', '2022-10-02 03:36:16'),
(7, 'neha', 'neha123', 'neha21@gmail.com', '7894561237', '2022-10-07 10:07:45');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `product_id`, `added_on`) VALUES
(16, 1, 4, '2020-05-13 08:54:24'),
(17, 1, 6, '2020-05-15 12:53:28'),
(19, 6, 17, '2022-10-02 03:38:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_status`
--
ALTER TABLE `order_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `order_status`
--
ALTER TABLE `order_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
